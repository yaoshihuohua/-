#ifndef GRAPH_H
#define GRAPH_H
#include <QString>
#include <vector>
#include <QDebug>
#include <QVector>
#include <unordered_map>
#include <queue>
#include <limits>
struct Vertex {
    QString name;
    QString code;
    QString summary;
    // 可以添加其他属性
};

struct Edge {
    int startVertex; // 起点
    int endVertex;   // 终点
    double length;   // 路径长度
    // 可以添加其他属性
};
struct PathInfo {
    QVector<int> path;
    double distance;
};
struct ComparePairs {
    bool operator()(const std::pair<double, int>& a, const std::pair<double, int>& b) const {
        return a.first > b.first; // 比较两个 std::pair<double, int> 中的第一个元素（即距离）
    }
};
// 定义图的结构
class Graph {
public:
    Graph(int verticesCount); // 构造函数，传入节点数目
    void addEdge(int src, int dest, double length); // 添加边
    void addVertex(Vertex vertex); // 添加节点
    std::vector<Vertex> vertices; // 节点集合
    std::vector<std::vector<Edge>> adjacencyList; // 邻接表表示边
    QVector<int> findCutPoints();
    void performDepthFirstSearch(int node, int parentNode, QVector<bool>& visited, QVector<int>& discoveryTime,
                                 QVector<int>& lowestReachable, int& globalTime, QVector<int>& cutPoints);
    QString getNodeName(int node);
    int getVertexIndexByName(const QString& vertexName);
    PathInfo calculateShortestPath(int startVertexIndex, int endVertexIndex);
    void findAllPaths(int startVertexIndex, int endVertexIndex, QVector<QVector<int>>& allPaths, QVector<int>& currentPath, QVector<bool>& visited);
    QVector<QVector<int>> getAllPaths(int startVertexIndex, int endVertexIndex);
    QString getNodesummary(int node);
    PathInfo shortestPathThroughVertices(const QVector<int>& nodesToVisit);
private:

};

#endif // GRAPH_H
