#ifndef GUDIE_H
#define GUDIE_H

#include <QMainWindow>
#include <QPixmap>
#include <QDebug>
#include <QFile>
#include <QTextStream>
#include "graph.h"
QT_BEGIN_NAMESPACE
namespace Ui { class Gudie; }
QT_END_NAMESPACE

class Gudie : public QMainWindow
{
    Q_OBJECT

public:
    Gudie(QWidget *parent = nullptr);
    ~Gudie();
    Graph *graph;
    Vertex vertex;
    void findShortestPath(int startVertexName,int endVertexName);
    int getVertexIndexByName(const QString& vertexName, const Graph& graph);
private slots:
    void on_shortestway_clicked();

    void on_articulation_clicked();

    void on_allway_clicked();

    void on_search_clicked();

    void on_multiway_clicked();

private:
    Ui::Gudie *ui;
};
#endif // GUDIE_H
