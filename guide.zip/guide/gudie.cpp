#include "gudie.h"
#include "ui_gudie.h"
#include "graph.h"
Gudie::Gudie(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Gudie)
{
    ui->setupUi(this);
    graph = new Graph(12);
    QFile file1(":/file/map.txt");
    if (!file1.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Failed to open file!";
        return;
    }
    QTextStream in(&file1);
    while (!in.atEnd()) {
        QString line = in.readLine();

        // 分割行，获取编号和节点名称
        QStringList parts = line.split(' ');
        if (parts.size() >= 2) {
            int vertexID = parts[0].toInt(); // 节点编号
            QString vertexName = parts.mid(1).join(' '); // 节点名称

            // 读取下一行获取节点详细信息
            QString nodeDetails;
            if (!in.atEnd()) {
                nodeDetails = in.readLine(); // 读取详细信息
            }

            // 创建节点对象并添加到图中

            vertex.name = vertexName;
            vertex.code = QString::number(vertexID);
            vertex.summary = nodeDetails;

            graph->addVertex(vertex);
        }
    }
    file1.close();
    QPixmap mapImage(":/file/map.jpg");
    if (!mapImage.isNull()) {
        QPixmap scaledImage = mapImage.scaled(ui->img->size());
        ui->img->setPixmap(scaledImage);
    } else {
        qDebug() << "Failed to load image!";
    }
    QFile file(":/file/map1.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Failed to open file!";
        return;
    }
    QTextStream inputStream(&file);
    while (!inputStream.atEnd()) {
        QString line = inputStream.readLine();

        QStringList parts = line.split(' ');
        if (parts.size() >= 3) {
            int src = parts[0].toInt();    // 起点
            int dest = parts[1].toInt();   // 终点
            double length = parts[2].toDouble(); // 路径长度

            // 添加边到图中
            graph->addEdge(src, dest, length);
        }
    }
    file.close();

}

Gudie::~Gudie()
{
    delete ui;
}


void Gudie::on_shortestway_clicked()
{
    int start = ui->start->text().toInt();
    int end = ui->end->text().toInt();
    findShortestPath(start,end);
}

void Gudie::on_articulation_clicked()
{
    QVector<int> cutPoints = graph->findCutPoints();

    if (cutPoints.isEmpty()) {
        QString result= "这个图中没有关节点.";
        ui->artBrowser->setText(result);
    } else {
        QString result= "图中关节点为:";
        for (int node : cutPoints) {
            QString nodeName = graph->getNodeName(node);
            result = result + nodeName +',';
            ui->artBrowser->setText(result);
        }
    }
}
int Gudie::getVertexIndexByName(const QString& vertexName, const Graph& graph) {
    for (int i = 0; i < graph.vertices.size(); ++i) {
        if (graph.vertices[i].name == vertexName) {
            return i; // 返回节点在 vertices 数组中的索引
        }
    }
    return -1; // 如果未找到对应名称的节点索引，返回 -1 或其他标识
}

void Gudie::findShortestPath(int startVertexIndex, int endVertexIndex) {
    startVertexIndex--;
    endVertexIndex--;
    if (startVertexIndex == -1 || endVertexIndex == -1) {
        // 处理找不到节点索引的情况
        qDebug() << "One or both vertices not found.";
        return;
    }

    QVector<int> shortestPath;
    PathInfo shortestPathInfo = graph->calculateShortestPath(startVertexIndex, endVertexIndex);

    if (shortestPathInfo.distance == -1) {
        // 处理无法找到最短路径的情况
        QString reslut= "No path found between these vertices.";
        ui->allway->setText(reslut);
        return;
    }
    QString finaldis,finalpath;
    QString startVertexName = graph->getNodeName(startVertexIndex);
    QString endVertexName = graph->getNodeName(endVertexIndex);
    finaldis = startVertexName +"和" + endVertexName + "之间的最短距离是：" + QString::number(shortestPathInfo.distance); +"\n";
    finalpath = "最短路径：";
    for (int node : shortestPathInfo.path) {
        QString nodeName = graph->getNodeName(node);
        finalpath += "->" + nodeName;
    }
    ui->allwayBrowser->append(finaldis);
    ui->allwayBrowser->append(finalpath);
}

void Gudie::on_allway_clicked()
{
    int startVertexIndex = ui->start->text().toInt();
    int endVertexIndex = ui->end->text().toInt();
    startVertexIndex--;
    endVertexIndex--;
    QVector<QVector<int>> allPaths = graph->getAllPaths(startVertexIndex, endVertexIndex);
    QString startVertexName = graph->getNodeName(startVertexIndex);
    QString endVertexName = graph->getNodeName(endVertexIndex);
    // 在 QTextBrowser 中显示所有路径信息
    for (const QVector<int>& path : allPaths) {
        QString pathText = startVertexName +"和" + endVertexName + "之间的路径：";
        for (int node : path) {
            QString nodeName = graph->getNodeName(node);
            pathText += "->"+nodeName ;
        }
        ui->allwayBrowser->append(pathText);
    }
}

void Gudie::on_search_clicked()
{
    int point = ui->point->text().toInt();
    point--;
    QString name = "景点：" +graph->getNodeName(point);
    QString sum = "简介："+graph->getNodesummary(point)+"\n";
    ui->shortestBrowser->append(name);
    ui->shortestBrowser->append(sum);
}

void Gudie::on_multiway_clicked()
{
    QStringList nodesList = ui->mulit->text().split(","); // 从 QLineEdit 中获取节点编号字符串，并按逗号拆分为列表
    qDebug()<<nodesList;
    QVector<int> nodes;
    for (const QString& nodeStr : nodesList) {
        int nodeint = nodeStr.toInt();
        nodeint--;
        nodes.append(nodeint); // 将字符串转换为整数，并存储在 nodes 向量中
    }
    qDebug()<<nodes;
    PathInfo shortestPath = graph->shortestPathThroughVertices(nodes);
    int prevNode = -1;
    // 在 QTextBrowser 中显示最短路径信息
    QString pathText = "通过的最短路径为：";
    for (int node : shortestPath.path) {
        if (prevNode != -1 && node == prevNode) {
            continue;
        }
        prevNode = node;
        QString nodename = graph->getNodeName(node);
        pathText += "->"+ nodename;
    }
    ui->multBrowser->append(pathText);
    ui->multBrowser->append("最短距离为:" + QString::number(shortestPath.distance));
}
