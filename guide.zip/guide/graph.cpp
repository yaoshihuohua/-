#include "graph.h"

Graph::Graph(int verticesCount) {
    adjacencyList.resize(verticesCount); // 根据节点数目初始化邻接表
}

void Graph::addEdge(int src, int dest, double length) {
    Edge edge;
    edge.startVertex = src;
    edge.endVertex = dest;
    edge.length = length;

    adjacencyList[src].push_back(edge);
    // 如果是无向图，还需加上 dest 到 src 的边
    edge.startVertex = dest;
    edge.endVertex = src;
    adjacencyList[dest].push_back(edge);
}

void Graph::addVertex(Vertex vertex) {
    vertices.push_back(vertex);
}

QVector<int> Graph::findCutPoints() {
    QVector<bool> visited(vertices.size(), false);
    QVector<int> discoveryTime(vertices.size(), -1);
    QVector<int> lowestReachable(vertices.size(), -1);
    QVector<int> cutPoints;

    int globalTime = 0;

    for (int i = 0; i < vertices.size(); ++i) {
        if (!visited[i]) {
            performDepthFirstSearch(i, -1, visited, discoveryTime, lowestReachable, globalTime, cutPoints);
        }
    }

    return cutPoints;
}

void Graph::performDepthFirstSearch(int node, int parentNode, QVector<bool>& visited, QVector<int>& discoveryTime,
                                    QVector<int>& lowestReachable, int& globalTime, QVector<int>& cutPoints) {
    visited[node] = true;
    ++globalTime;
    discoveryTime[node] = globalTime;
    lowestReachable[node] = globalTime;
    int childCount = 0;
    bool isCutPoint = false;

    for (const Edge &e : adjacencyList[node]) {
        int neighbor = e.endVertex;
        if (!visited[neighbor]) {
            ++childCount;
            performDepthFirstSearch(neighbor, node, visited, discoveryTime, lowestReachable, globalTime, cutPoints);

            lowestReachable[node] = qMin(lowestReachable[node], lowestReachable[neighbor]);

            if (lowestReachable[neighbor] >= discoveryTime[node] && parentNode != -1) {
                isCutPoint = true;
            }
        } else if (neighbor != parentNode) {
            lowestReachable[node] = qMin(lowestReachable[node], discoveryTime[neighbor]);
        }
    }

    if ((parentNode == -1 && childCount > 1) || (parentNode != -1 && isCutPoint)) {
        cutPoints.append(node); // 将割点信息存入列表
    }
}

QString Graph::getNodeName(int node){
    if (node >= 0 && node < vertices.size()) {
        return vertices[node].name;
    }
    return QString(); // 如果节点编号不存在，返回一个空字符串
}
QString Graph::getNodesummary(int node){
    if (node >= 0 && node < vertices.size()) {
        return vertices[node].summary;
    }
    return QString(); // 如果节点编号不存在，返回一个空字符串
}

int Graph::getVertexIndexByName(const QString& vertexName) {
    for (int i = 0; i < vertices.size(); ++i) {
        if (vertices[i].name == vertexName) {
            return i; // 返回节点在 vertices 数组中的索引
        }
    }
    return -1; // 如果未找到对应名称的节点索引，返回 -1 或其他标识
}

PathInfo Graph::calculateShortestPath(int startVertexIndex, int endVertexIndex){

    const int INF = 1e9; // 一个很大的数作为无穷大

    QVector<double> distance(vertices.size(), INF); // 存储起点到各点的最短距离
    QVector<int> parent(vertices.size(), -1); // 存储最短路径上每个节点的父节点
    QVector<bool> visited(vertices.size(), false); // 记录节点是否已访问

    distance[startVertexIndex] = 0;

    for (int i = 0; i < vertices.size() - 1; ++i) {
        int u = -1;
        // 从尚未访问的节点中找到当前距离起点最近的节点
        for (int j = 0; j < vertices.size(); ++j) {
            if (!visited[j] && (u == -1 || distance[j] < distance[u])) {
                u = j;
            }
        }

        visited[u] = true;

        // 更新与节点 u 相连的节点的最短距离
        for (const Edge& edge : adjacencyList[u]) {
            int v = edge.endVertex;
            double weight = edge.length;

            if (!visited[v] && distance[u] + weight < distance[v]) {
                distance[v] = distance[u] + weight;
                parent[v] = u;
            }
        }
    }
    PathInfo pathInfo;
    pathInfo.distance = distance[endVertexIndex];

    // 构建最短路径
    pathInfo.path.clear();
    int current = endVertexIndex;
    while (current != -1) {
        pathInfo.path.prepend(current);
        current = parent[current];
    }

    return pathInfo;
}

void Graph::findAllPaths(int startVertexIndex, int endVertexIndex, QVector<QVector<int>>& allPaths, QVector<int>& currentPath, QVector<bool>& visited) {
    visited[startVertexIndex] = true;
    currentPath.append(startVertexIndex);

    if (startVertexIndex == endVertexIndex) {
        allPaths.append(currentPath);
    } else {
        for (const Edge& edge : adjacencyList[startVertexIndex]) {
            int nextVertexIndex = edge.endVertex;
            if (!visited[nextVertexIndex]) {
                findAllPaths(nextVertexIndex, endVertexIndex, allPaths, currentPath, visited);
            }
        }
    }

    visited[startVertexIndex] = false;
    currentPath.removeLast();
}

QVector<QVector<int>> Graph::getAllPaths(int startVertexIndex, int endVertexIndex) {
    QVector<QVector<int>> allPaths;
    QVector<int> currentPath;
    QVector<bool> visited(vertices.size(), false);

    findAllPaths(startVertexIndex, endVertexIndex, allPaths, currentPath, visited);

    return allPaths;
}


PathInfo Graph::shortestPathThroughVertices(const QVector<int>& nodesToVisit) {
    QVector<int> sortedNodes = nodesToVisit;
    std::sort(sortedNodes.begin(), sortedNodes.end());
    PathInfo shortestPath;
    shortestPath.distance = 0; // 初始化累计距离为 0

    for (int i = 0; i < sortedNodes.size()-1; ++i) {
        int j=i+1;
        int startVertexIndex = sortedNodes[i];
        int endVertexIndex = sortedNodes[j];

        // 计算节点 startVertexIndex 到 endVertexIndex 的最短路径
        PathInfo currentPath = calculateShortestPath(startVertexIndex, endVertexIndex);

        // 累加路径距离
        shortestPath.distance += currentPath.distance;

        // 将当前路径添加到 shortestPath 的路径中
        shortestPath.path.append(currentPath.path);
    }

    return shortestPath;
}

